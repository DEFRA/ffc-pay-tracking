# Scenarios

## Mr Unsettled Top Up
FRN: 1000000001

PR1: £1000

PR2: £1500 (+£500)

## Mr Settled Top Up
FRN: 1000000002

PR1: £1000

PAY Q1: £250

PR2: £1500 (+£500)

## Mr Settled Reduction
FRN: 1000000003

PR1: £1000

PAY Q1: £250

PR2: £500 (-£500)

## Mr Unsettled Reduction
FRN: 1000000004

PR1: £1000

PR2: £500 (-£500)

## Mr Recovery
FRN: 1000000005

PR1: £1000

PAY Q1: £250

PAY Q2: £250

PAY Q3: £250

PR2: £500 (-£500)

## Mr Zero Value Split
FRN: 1000000006

PR1: £1000

PR2: £1000 (+£0)

